package com.myapplicationdev.android.p04quiz;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.ArrayList;

public class Adapter extends ArrayAdapter<Car> {
    private ArrayList<Car> car;
    private Context context;
    private TextView tvID;
    private TextView tvBrand;
    private TextView tvLitre;
    int resource;

    public Adapter(Context context, int resource,
                   ArrayList<Car> objects) {
        super(context, resource, objects);
        // Store the ArrayList of objects passed to this adapter
        car = objects;
        // Store Context object as we would need to use it later
        this.context = context;
    }
    // getView() is called every time for every row
    @Override
    public View getView(int pos, View convertView, ViewGroup parent) {
        LayoutInflater inflater = (LayoutInflater) context
                .getSystemService(Context.LAYOUT_INFLATER_SERVICE);

        View rowView = inflater.inflate(resource, parent, false);
        // Get the TextView object

        tvBrand = rowView.findViewById(R.id.etBrand);
        tvLitre = rowView.findViewById(R.id.etLitre);

        Car currentCar = car.get(pos);
        tvID.setText(String.valueOf(currentCar.getId()));
        tvBrand.setText(currentCar.getBrand());
        tvLitre.setText(currentCar.getLitre().toString());
        return rowView;
    }

}
