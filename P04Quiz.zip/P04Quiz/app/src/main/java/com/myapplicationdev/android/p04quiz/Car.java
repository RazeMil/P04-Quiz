package com.myapplicationdev.android.p04quiz;

public class Car {
    private int id;
    private String brand;
    private Double litre;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getBrand() {
        return brand;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    public Double getLitre() {
        return litre;
    }

    public void setLitre(Double litre) {
        this.litre = litre;
    }

    public Car(int id, String brand, Double litre) {
        this.id = id;
        this.brand = brand;
        this.litre = litre;
    }
}
